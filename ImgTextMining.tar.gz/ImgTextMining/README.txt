		Text Mining for Automatic Image Tagging Dataset	
    	       =================================================
			          Version 1.0
			       August 23rd, 2010

		   Chee Wee Leong, Rada Mihalcea, Samer Hassan
		      Language and Information Technologies
		             University of North Texas
                cheeweeleong@my.unt.edu, rada@cs.unt.edu, samer@unt.edu



CONTENTS
1. Introduction
2. Data Set
3. Annotation Guidelines
4. Format
5. Feedback
6. Citation Info

=======================
1. Introduction

This README v1.0 (August, 2010) for the Text Mining for Automatic Image 
Tagging dataset comes from the archive hosted at the following URL
http://lit.csci.unt.edu/index.php/Downloads


=======================
2. Data Set

This dataset contains images, texts and gold-standard annotations of 300
image-text pairs randomly collected over the web. The texts are tokenized
and extracted "as-is" using a DOM HTML parser 
(http://search.cpan.org/dist/HTML-ContentExtractor/), and represents
raw, unstructured data from unrestricted domains.


=======================
3. Annotation Guidelines

Our annotation templates and instructions used in Amazon Mechanical Turk 
can be found in Guidelines_for_Words_Annotation.pdf and 
Guidelines_for_Collocation_Annotation.pdf.

=======================
4. Format

The list of files and folders contained in this archive are explained
below

		
	a) File: gold_annot.txt
		
		gold-standard annotations by 5 users from Amazon Mechanical Turk
		in the format used for Lexical Substitution Task*. Stemming is 
		applied after collecting the annotations as a post-processing step. 
		To download the scoring tools, please go to 
		http://www.dianamccarthy.co.uk/task10index.html#resources.

		* Diana McCarthy and Roberto Navigli. 2007. The semeval English lexical 
		substitution task. In Proceedings of the ACL Semeval workshop


	b) File: captions.txt

		list of extracted captions, where available in the "ALT" tag of the 
		images.
		
	c) File: URL.txt
		
		list of 300 URLs where the image-text pairs are extracted. 
		Note that over time, some links may become obsolete, or their
		contents may have changed.
		
	d) Folder: images\
		
		folder containing the 300 images, indexed 1-300  


	e) Folder: texts\
		
		folder containing extracted texts from the associated webpages 
		of the images, indexed 1-300 


=======================
5. Feedback

For further questions or inquiries about this data set, you can contact:
Ben Leong (cheeweeleong@my.unt.edu) or Rada Mihalcea (rada@cs.unt.edu).


=======================
6. Citation Info 

If you use this data set, please cite:

@InProceedings{Leong10,
  author =    {Chee Wee Leong and Rada Mihalcea and Samer Hassan},
  title =     {Text Mining for Automatic Image Tagging},
  booktitle = {Proceedings of the International Conference on 
		Computational Linguistics},
  address =   {Beijing, China},
  year =      {2010}
}


